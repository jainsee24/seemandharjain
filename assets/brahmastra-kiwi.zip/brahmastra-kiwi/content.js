if(typeof browser==='undefined'){var browser=chrome;}

function repeat(fn,times,interval){let n=0;const id=setInterval(()=>{try{fn();}catch(e){console.error(e);} if(++n>=times)clearInterval(id);},interval);}

function applyPriceModification(data){const{website,mrp,discountPrice}=data;const map={target:updateTargetPrice,bananaRepublic:updateBananaRepublicPrice,bananaRepublicFactory:updateBananaRepublicFactoryPrice,dicks:updateDicksPrice,bloomingdale:updateBloomingdalesPrice,saksAvenue:updateSaksAvenuePrice,victoriasSecret:updateVictoriasSecretPrice,walmart:updateWalmartPrice,abercrombie:updateAbercrombiePrice,kohls:updateKohlsPrice};const fn=map[website];if(fn){repeat(()=>fn(mrp,discountPrice),5,2000);}else{console.log('Website not supported yet.');}}

function performSearchReplace(searchText,replaceText){const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false);let node;while(node=w.nextNode()){if(!searchText)continue;node.nodeValue=node.nodeValue.split(searchText).join(replaceText);} }
function repeatSearchReplaceOnce(pairs){let count=0;const id=setInterval(()=>{pairs.forEach(p=>{if(p.searchText)performSearchReplace(p.searchText,p.replaceText);});if(++count>=50)clearInterval(id);},2000);}
function applyMultipleSearchReplace(pairs){repeatSearchReplaceOnce(pairs||[]);}

function performCutdownReplace(searchText,replaceText){if(!searchText)return;const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(node){const p=node.parentElement;if(!p)return NodeFilter.FILTER_REJECT;const tag=p.tagName;if(tag==='SCRIPT'||tag==='STYLE')return NodeFilter.FILTER_REJECT;if(p.closest('[data-cutdown="1"]'))return NodeFilter.FILTER_REJECT;if(!node.nodeValue||node.nodeValue.indexOf(searchText)===-1)return NodeFilter.FILTER_REJECT;return NodeFilter.FILTER_ACCEPT;}},false);let node;while((node=walker.nextNode())){const html=node.nodeValue.split(searchText).join(`${replaceText} <s>${searchText}</s>`);const span=document.createElement('span');span.setAttribute('data-cutdown','1');span.innerHTML=html;node.parentNode.replaceChild(span,node);} }
function repeatCutdownReplaceOnce(pairs){let count=0;const id=setInterval(()=>{pairs.forEach(p=>{if(p.searchText)performCutdownReplace(p.searchText,p.replaceText||'');});if(++count>=50)clearInterval(id);},2000);}
function applyMultipleCutdownReplace(pairs){repeatCutdownReplaceOnce(pairs||[]);}

function getMonthEndExpiry(){const now=new Date();const lastDay=new Date(now.getFullYear(),now.getMonth()+1,0);const m=lastDay.getMonth()+1;const d=lastDay.getDate();const y2=lastDay.getFullYear()%100;return `${m}/${d}/${y2}`;}
function buildAmcHtml(){const expiry=getMonthEndExpiry();return `
    <div class="mx-auto my-4 grid w-full max-w-[450px] col-span-2 md:col-span-1">
      <h1 class="mb-4 headline">Your Rewards</h1>
      <div class="grid w-full flex-1 grid-cols-2 gap-4 rounded-xl lg:flex lg:flex-wrap">
        <div class="flex items-center rounded-xl h-[80px] px-4 max-h-[80px] bg-purple-700/85 col-span-2 w-full lg:w-[450px]">
          <div class="my-auto flex items-center gap-4">
            <div class="relative h-12 w-12">
              <img alt="Birthday Reward" loading="lazy" width="150" height="150" decoding="async" class="absolute inset-0 m-auto h-[45px] w-[45px]" src="https://amc-theatres-res.cloudinary.com/image/upload/c_fill/c_limit,w_150/f_auto/q_auto/amc-cdn/static/images/2024/icon-birthday-popcorn-drink-3d.png" style="color: transparent;">
            </div>
            <dl class="flex flex-col-reverse">
              <dt class="whitespace-nowrap text-100 text-gray-200">Expires ${expiry}</dt>
              <dd class="text-100">Happy Birthday!</dd>
              <dd class="text-200 font-bold md:text-300">Free Large Popcorn Birthday Gift</dd>
            </dl>
          </div>
        </div>
        <div class="flex items-center rounded-xl h-[80px] px-4 max-h-[80px] bg-purple-700/85 col-span-2 w-full lg:w-[450px]">
          <div class="my-auto flex items-center gap-4">
            <div class="relative h-12 w-12">
              <img alt="Birthday Reward" loading="lazy" width="150" height="150" decoding="async" class="absolute inset-0 m-auto h-[45px] w-[45px]" src="https://amc-theatres-res.cloudinary.com/image/upload/c_fill/c_limit,w_150/f_auto/q_auto/amc-cdn/static/images/2024/icon-birthday-popcorn-drink-3d.png" style="color: transparent;">
            </div>
            <dl class="flex flex-col-reverse">
              <dt class="whitespace-nowrap text-100 text-gray-200">Expires ${expiry}</dt>
              <dd class="text-100">Happy Birthday!</dd>
              <dd class="text-200 font-bold md:text-300">Free Large Drink Birthday Gift</dd>
            </dl>
          </div>
        </div>
      </div>
    </div>`;}
function applyAMCReplacement(){const selector='div.mx-auto.my-4.grid.w-full.max-w-\\[450px\\].col-span-2.md\\:col-span-1';const html=buildAmcHtml();document.querySelectorAll(selector).forEach(el=>{el.outerHTML=html;});}

// === Price updaters (site-specific)
function updateTargetPrice(mrp,discountPrice){const discPct=((mrp-discountPrice)/mrp)*100;const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;const S=`$${(mrp-discountPrice).toFixed(2)} (${discPct.toFixed(0)}% off)`;const nodes=document.querySelectorAll('[data-module-type="ProductDetailPrice"]');nodes.forEach(n=>{n.outerHTML=`
<div data-module-type="ProductDetailPrice"><div class="h-margin-a-module-gap" style="max-width:480px"><div class="sc-28c7f1f0-0 dNTjzJ sc-f1b5c60b-1 gyUBzs" data-test="@web/Price/PriceFull"><div>
  <span class="h-text-red"><span data-test="product-price" class="sc-28c7f1f0-1 iydcNv">${D}</span></span>
  <span class="h-text-sm h-text-grayDark" data-test="product-regular-price">reg <span class="h-text-line-through">${M}</span></span>
  <div class="h-text-md"><span class="h-text-red h-text-bold h-text-md" data-test="product-offer-type">Sale&nbsp;</span>
  <span class="h-text-grayDark h-text-normal h-text-sm" data-test="product-savings-amount">save ${S}</span></div>
</div></div></div></div>`;});}
function updateBananaRepublicPrice(mrp,discountPrice){const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;document.querySelectorAll('.swatch-price.swatch-price__inner').forEach(c=>{c.outerHTML=`
<div class="swatch-price swatch-price__inner"><div aria-hidden="true" class="swatch-price__regular pdp-mfe-1urva88" id="price--${discountPrice.toFixed(2).replace('.', '-')}">
  <div class="product-price__markdown"><span aria-label="Was ${M}" class="product-price__strike pdp-mfe-fmo2bi">${M}</span></div>
  <div aria-label="Now ${D}" class="product-price__highlight pdp-mfe-fmo2bi"><div class="amount-price">${D}</div><div class="line-price"></div></div>
</div></div>`;});}
function updateBananaRepublicFactoryPrice(mrp,discountPrice){const pct=((mrp-discountPrice)/mrp)*100;const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;const P=`${pct.toFixed(0)}% off`;document.querySelectorAll('.swatch-price.swatch-price__inner').forEach(c=>{c.outerHTML=`
<div class="swatch-price swatch-price__inner"><div aria-hidden="true" class="swatch-price__regular pdp-mfe-1urva88 swatch-price--sticky" id="price--${discountPrice.toFixed(2).replace('.', '-')}">
  <div class="product-price__markdown"><span aria-label="Was ${M}" class="product-price__strike pdp-mfe-uegzgs">${M}</span><span class="product-price__percentage-off pdp-mfe-uegzgs">${P}</span></div>
  <div aria-label="Now ${D}" class="product-price__highlight product-price__option pdp-mfe-uegzgs"><div class="amount-price">Now ${D}</div><div class="line-price"></div></div>
</div></div>`;});}
function updateDicksPrice(mrp,discountPrice){const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;document.querySelectorAll('div.price').forEach(c=>{c.outerHTML=`
<div class="price"><div class="product-price-summary-container"><div id="pdp-price-summary" class="product-price-summary"><div class="ng-star-inserted">
  <div class="hmf-mb-xxxs hmf-header-bold-l markdown-clearance-price-color"><span class="product-price">${D}</span></div>
  <div class="hmf-display-flex hmf-body-m"><span class="price-list"><span class="ng-star-inserted">${M}</span></span><span class="price-star">*</span></div>
</div></div></div></div>`;});}
function updateBloomingdalesPrice(mrp,discountPrice){const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;document.querySelectorAll('div[data-el="price-details"]').forEach(c=>{c.outerHTML=`
<div data-el="price-details"><div><div class="grid-x tiered-prices"><div><span class="large red">${D}</span></div><div class="price-strike-lg large">${M}</div><div><button class="link-sm" data-testid="details-link-bcom"> Details </button></div></div></div></div>`;});}
function updateSaksAvenuePrice(mrp,discountPrice){const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;document.querySelectorAll('div[data-testid="pricing.displayPrice"]').forEach(c=>{c.outerHTML=`
<div data-testid="pricing.displayPrice" class="sdui-container h-container h-container-layout-none" style="gap:8px;justify-content:start;align-items:center">
  <span class="textview cxds-labelLDefault" data-testid="pricing.displayPrice.currentPrice">${D}</span>
  <span class="textview cxds-labelLMarkdown" data-testid="pricing.displayPrice.strikethroughPrice" style="text-decoration:line-through">${M}</span>
</div>`;});}
function updateVictoriasSecretPrice(mrp,discountPrice){const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;document.querySelectorAll('div[data-testid="ProductPrice"]').forEach(c=>{c.outerHTML=`
<div class="prism-price" data-testid="ProductPrice"><del><span class="prism-danger-zone">${M}</span></del><ins><span class="prism-danger-zone">${D}</span></ins></div>`;});}
function updateAbercrombiePrice(mrp,discountPrice){const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;document.querySelectorAll('div.product-price-container[data-product-brand="anf"]').forEach(c=>{c.outerHTML=discountPrice<mrp?`
<div class="product-price-container" data-product-brand="anf"><span class="product-price" data-brand="anf" data-testid="product-price" data-variant="discount"><span class="product-price-text-wrapper" data-testid="product-price-text-wrapper"><span class="product-price-text product-price-font-size" data-variant="original">${M}</span><span class="product-price-text product-price-font-size" data-variant="discount">${D}</span></span></span></div>`:`
<div class="product-price-container" data-product-brand="anf"><span class="product-price" data-brand="anf" data-testid="product-price" data-variant="original"><span class="product-price-text-wrapper" data-testid="product-price-text-wrapper"><span class="product-price-text product-price-font-size">${M}</span></span></span></div>`;});}
function updateKohlsPrice(mrp,discountPrice){const pct=((mrp-discountPrice)/mrp)*100;const M=`$${mrp.toFixed(2)} Reg`;const D=`$${discountPrice.toFixed(2)}`;const S=`$${(mrp-discountPrice).toFixed(2)} (${pct.toFixed(0)}% off)`;const el=document.querySelector('#pdpprice-price-container');if(!el){console.log('Kohls price container not found.');return;} el.outerHTML=`
<div id="pdpprice-price-container"><p class="pdpprice-row1 tag-nostyle-fatc-excl-price"><span class="pdpprice-row1-reg-price pdpprice-row1-reg-price-striked">${M}</span></p><p class="pdpprice-row2"><span class="pdpprice-row2-main-text pdpprice-row2-main-text-red">${D}</span><span class="pdpprice-row2-main-text-label-sale">Sale</span><span class="pdpprice-row2-savings">You save ${S}</span></p></div>`;}
function updateWalmartPrice(mrp,discountPrice){const M=`$${mrp.toFixed(2)}`;const D=`$${discountPrice.toFixed(2)}`;const savings=`$${(mrp-discountPrice).toFixed(2)}`;document.querySelectorAll('div.mh3.mt3').forEach(c=>{c.outerHTML=`
<div class="mh3 mt3"><span data-testid="price-wrap" class="lh-copy mr2 f4 dark-gray green"><span class="inline-flex flex-row items-center"><span class="v-mid nowrap f1" itemprop="price"><span class="b"><span class="f2">Now </span><span class="f4" style="margin-right:2px;vertical-align:1ex;font-size:1.125rem">$</span><span style="font-size:1.75rem">${Math.floor(discountPrice)}</span><span class="f4" style="margin-right:2px;vertical-align:1ex;font-size:1.125rem">${(discountPrice%1).toFixed(2).substring(2)}</span></span></span><span class="inline-flex flex-column mh2 gray"><span class="inline-flex flex-column gray"><span class="inline-flex flex-row"><span class="w_iUH7"><div>You save ${savings}</div></span><span class="mr2"><div class="flex items-center" aria-hidden="true" data-testid="dollar-saving"><span class="ph1 mr1 b br1 nowrap f7 bg-washed-green green">You save</span><span class="b lh-copy f7 green">${savings}</span></div></span><div class="nowrap items-center inline-flex"><span class="w_iUH7">was ${M}</span><span aria-hidden="true" data-seo-id="strike-through-price" class="mr2 f6 gray v-mid strike">${M}</span></div></span></span></span></span></div>`;});
  document.querySelectorAll('span[itemprop="price"][data-seo-id="hero-price"]').forEach(s=>{s.outerHTML=`<span itemprop="price" data-seo-id="hero-price">${D}</span>`;});
  document.querySelectorAll('div[data-testid="sticky-add-to-cart-price"]').forEach(d=>{d.outerHTML=`<div data-testid="sticky-add-to-cart-price" aria-hidden="false" class="relative lh-title f6 gray"><span class="b dark-gray mr2 f4 dib mt2">${D}</span></div>`;});
  document.querySelectorAll('div[data-testid="ip-subscription-options-one-time"]').forEach(d=>{d.outerHTML=`<div data-testid="ip-subscription-options-one-time" class="pa3 ba br3 flex items-center"><label class="mr3"><input type="radio" checked></label><div class="f6 pointer flex-auto b"><div class="flex justify-between items-center"><span class="w_iUH7">One-time purchase ${D}</span><div class="tr ml2">${D}</div></div></div></div>`;});
}

// --- Messaging & init ---
browser.runtime.onMessage.addListener((req,s,res)=>{
  switch(req.action){
    case 'updatePrice': applyPriceModification(req.data); break;
    case 'clearPriceModification': location.reload(); break;
    case 'searchReplaceAll': applyMultipleSearchReplace(req.data); break;
    case 'clearSearchReplace': location.reload(); break;
    case 'searchReplaceCutdownAll': applyMultipleCutdownReplace(req.data); break;
    case 'clearSearchReplaceCutdown': location.reload(); break;
    case 'applyAMC': applyAMCReplacement(); break;
    case 'getPageSnapshot': try{const raw=document.documentElement.outerHTML||'';const slim=raw.replace(/\s+/g,' ').slice(0,3000);res({html:slim,url:location.href});}catch(e){res({html:'',url:location.href});} return true;
    case 'executeGeneratedCode': try{(new Function(String(req.code||'')))();res({ok:true});}catch(e){res({ok:false,error:String(e)});} return true;
  }
});

// On load, hydrate saved states
browser.storage.local.get(['priceData','searchReplaceData','amcActive','cutReplaceData'],(r)=>{
  if(r.priceData)applyPriceModification(r.priceData);
  if(r.searchReplaceData)applyMultipleSearchReplace(r.searchReplaceData);
  if(r.cutReplaceData)applyMultipleCutdownReplace(r.cutReplaceData);
  if(r.amcActive)applyAMCReplacement();
});

// Auto-run saved code for this origin+path
(function(){
  function runSafely(code){try{(new Function(`(async()=>{try{ ${code} }catch(e){console.error('[Auto-run]',e);} })();`))();}catch(e){console.error('[Auto-run wrapper]',e);} }
  function autorunNow(code){runSafely(code);setTimeout(()=>runSafely(code),1500);setTimeout(()=>runSafely(code),4000);}
  try{const here=location.origin+location.pathname;browser.storage.local.get('autorunScripts',(v)=>{const map=v&&v.autorunScripts?v.autorunScripts:{};let best='';for(const k in map){if(here.startsWith(k)&&k.length>best.length)best=k;} if(best)autorunNow(map[best]);});}catch(e){console.error('[Auto-run init]',e);}
})();