if(typeof browser==='undefined'){var browser=chrome;}

function getActiveTab(){return new Promise(r=>browser.tabs.query({active:true,currentWindow:true},t=>r(t[0])));}
function setSpinner(show){const s=document.getElementById('genSpinner');if(s)s.hidden=!show;}

async function getKey(){return new Promise(r=>browser.storage.local.get('openaiApiKey',v=>r(v.openaiApiKey||'')));}
async function setKey(k){return new Promise(r=>browser.storage.local.set({openaiApiKey:k},r));}

function xhrJSON(url,method,headers,bodyStr){return new Promise((resolve,reject)=>{try{const x=new XMLHttpRequest();x.open(method,url,true);Object.entries(headers||{}).forEach(([k,v])=>x.setRequestHeader(k,v));x.onreadystatechange=()=>{if(x.readyState===4){if(x.status>=200&&x.status<300){try{resolve(JSON.parse(x.responseText));}catch(e){reject(new Error('Bad JSON: '+e.message));}}else{reject(new Error('HTTP '+x.status+' '+(x.responseText||'')));}}};x.onerror=()=>reject(new Error('Network error'));x.send(bodyStr);}catch(e){reject(e);}});}

async function callOpenAIFromPopup(promptText){
  const key='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';
  if(!key){throw new Error('Missing OpenAI API key. Save it below.');}
  const body={model:'gpt-5-mini',messages:[{role:'system',content:'Return ONLY JavaScript code that can run in a browser content script. No markdown, no explanations, no backticks. Use DOM APIs only.'},{role:'user',content:promptText}]};
  const data=await xhrJSON('https://api.openai.com/v1/chat/completions','POST',{'Content-Type':'application/json','Authorization':'Bearer '+key},JSON.stringify(body));
  const text=data?.choices?.[0]?.message?.content||''; if(!text) throw new Error('Empty completion.');
  return String(text).replace(/^```[a-z]*\n?|\n?```$/g,'').trim();
}

async function getPageSnapshotSafe(){
  const tab=await getActiveTab(); if(!tab) return {html:'',url:''};
  return new Promise(resolve=>{let settled=false;const timer=setTimeout(()=>{if(!settled){settled=true;resolve({html:'',url:''});}},7000);try{browser.tabs.sendMessage(tab.id,{action:'getPageSnapshot'},res=>{if(settled)return;clearTimeout(timer);if(browser.runtime.lastError){settled=true;return resolve({html:'',url:''});}settled=true;resolve(res||{html:'',url:''});});}catch(_){if(!settled){clearTimeout(timer);settled=true;resolve({html:'',url:''});}}});
}

// Load saved price + S/R + Key + Autorun status
document.addEventListener('DOMContentLoaded',async()=>{
  browser.storage.local.get(['priceData','searchReplaceData','cutReplaceData','autorunScripts','openaiApiKey'],res=>{
    if(res.priceData){const{website,mrp,discountPrice}=res.priceData;document.getElementById('website').value=website;document.getElementById('mrp').value=mrp;document.getElementById('discountPrice').value=discountPrice;}
    const pairs=res.searchReplaceData||[];for(let i=1;i<=5;i++){const p=pairs[i-1]||{};document.getElementById(`searchText${i}`).value=p.searchText||'';document.getElementById(`replaceText${i}`).value=p.replaceText||'';}
    const cp=res.cutReplaceData||[];for(let i=1;i<=2;i++){const p=cp[i-1]||{};document.getElementById(`cutSearchText${i}`).value=p.searchText||'';document.getElementById(`cutReplaceText${i}`).value=p.replaceText||'';}
    if(res.openaiApiKey){document.getElementById('apiKey').value='••••••••';document.getElementById('keyStatus').textContent='Key saved';}
  });

  // Autorun status for current page
  const tab=await getActiveTab();
  const st=document.getElementById('autorunStatus');
  const clr=document.getElementById('clearAutorun');
  if(tab&&tab.url){const here=(()=>{try{const u=new URL(tab.url);return u.origin+u.pathname;}catch{return '';}})();
    browser.storage.local.get('autorunScripts',v=>{const map=v.autorunScripts||{};let onKey='';for(const k in map){if(here.startsWith(k)&&k.length>onKey.length) onKey=k;} if(onKey){st.textContent='Auto-run: ON for this page';clr.disabled=false;clr.onclick=async()=>{delete map[onKey];await new Promise(r=>browser.storage.local.set({autorunScripts:map},r));st.textContent='Auto-run: OFF';clr.disabled=true;};}else{st.textContent='Auto-run: OFF';clr.disabled=true;}});
  } else {st.textContent='Auto-run: (no active tab)';}
});

// Save API key
document.getElementById('saveKey').addEventListener('click',async()=>{
  const inp=document.getElementById('apiKey');const v=(inp.value||'').trim();
  if(!v){document.getElementById('keyStatus').textContent='Enter a key starting with sk-...';return;}
  await setKey(v);document.getElementById('keyStatus').textContent='Saved';inp.value='••••••••';
});

// Price update
document.getElementById('updatePrice').addEventListener('click',()=>{
  const website=document.getElementById('website').value;
  const mrp=parseFloat(document.getElementById('mrp').value);
  const discountPrice=parseFloat(document.getElementById('discountPrice').value);
  if(isNaN(mrp)||isNaN(discountPrice)){alert('Please enter valid prices.');return;}
  const data={website,mrp,discountPrice};
  browser.storage.local.set({priceData:data},()=>{browser.tabs.query({active:true,currentWindow:true},tabs=>{browser.tabs.sendMessage(tabs[0].id,{action:'updatePrice',data});});});
});

// Clear price
document.getElementById('clearData').addEventListener('click',()=>{
  browser.storage.local.remove('priceData',()=>{
    document.getElementById('website').value='target';
    document.getElementById('mrp').value='';
    document.getElementById('discountPrice').value='';
    browser.tabs.query({active:true,currentWindow:true},tabs=>{browser.tabs.sendMessage(tabs[0].id,{action:'clearPriceModification'});});
  });
});

// Search/Replace save+apply
Array.from(document.querySelectorAll('.replace-btn')).forEach(btn=>{
  btn.addEventListener('click',()=>{
    const pairs=Array.from({length:5},(_,i)=>({searchText:document.getElementById(`searchText${i+1}`).value,replaceText:document.getElementById(`replaceText${i+1}`).value}));
    browser.storage.local.set({searchReplaceData:pairs},()=>{
      browser.tabs.query({active:true,currentWindow:true},tabs=>{browser.tabs.sendMessage(tabs[0].id,{action:'searchReplaceAll',data:pairs});});
    });
  });
});

document.getElementById('clearAllReplacements').addEventListener('click',()=>{
  browser.storage.local.remove('searchReplaceData',()=>{
    for(let i=1;i<=5;i++){document.getElementById(`searchText${i}`).value='';document.getElementById(`replaceText${i}`).value='';}
    browser.tabs.query({active:true,currentWindow:true},tabs=>{browser.tabs.sendMessage(tabs[0].id,{action:'clearSearchReplace'});});
  });
});

// AMC
document.getElementById('applyAmc').addEventListener('click',()=>{
  browser.storage.local.set({amcActive:true},()=>{
    browser.tabs.query({active:true,currentWindow:true},tabs=>{browser.tabs.sendMessage(tabs[0].id,{action:'applyAMC'});});
  });
});

// Cutdown replace save+apply (2 pairs)
Array.from(document.querySelectorAll('.replace-cutdown-btn')).forEach(btn=>{
  btn.addEventListener('click',()=>{
    const pairs=Array.from({length:2},(_,i)=>({searchText:document.getElementById(`cutSearchText${i+1}`).value,replaceText:document.getElementById(`cutReplaceText${i+1}`).value}));
    browser.storage.local.set({cutReplaceData:pairs},()=>{
      browser.tabs.query({active:true,currentWindow:true},tabs=>{browser.tabs.sendMessage(tabs[0].id,{action:'searchReplaceCutdownAll',data:pairs});});
    });
  });
});

document.getElementById('clearAllCutdown').addEventListener('click',()=>{
  browser.storage.local.remove('cutReplaceData',()=>{
    for(let i=1;i<=2;i++){document.getElementById(`cutSearchText${i}`).value='';document.getElementById(`cutReplaceText${i}`).value='';}
    browser.tabs.query({active:true,currentWindow:true},tabs=>{browser.tabs.sendMessage(tabs[0].id,{action:'clearSearchReplaceCutdown'});});
  });
});

// Generate JS (AI)
document.getElementById('generateJs').addEventListener('click',async()=>{
  const instruction=(document.getElementById('aiInstruction').value||'').trim();
  if(!instruction){alert('Type an instruction first.');return;}
  setSpinner(true);
  const codeBox=document.getElementById('generatedCode');const runBtn=document.getElementById('runGenerated');
  codeBox.textContent='';runBtn.disabled=true;
  const snapshot=await getPageSnapshotSafe();
  const slim=(snapshot.html||'').slice(0,3000);
  const prompt=`URL:\n${snapshot.url||''}\n\nINSTRUCTION:\n${instruction}\n\nPAGE_HTML_SNIPPET:\n${slim}`;
  try{const code=await callOpenAIFromPopup(prompt);codeBox.textContent=code;runBtn.disabled=false;}catch(e){codeBox.textContent='OpenAI error: '+(e&&e.message?e.message:String(e));}finally{setSpinner(false);}
});

// Run generated code + save autorun for this URL path
document.getElementById('runGenerated').addEventListener('click',async()=>{
  const raw=(document.getElementById('generatedCode').textContent||'').trim(); if(!raw){alert('No code to run.');return;}
  const tab=await getActiveTab(); if(!tab||!tab.id||!tab.url){alert('No active tab.');return;}
  const wrapped=`(async()=>{try{ ${raw} }catch(e){console.error('[AI Action] Error:',e);alert('Execution error: '+(e&&e.message?e.message:e));}})();`;
  try{
    if(browser.tabs&&browser.tabs.executeScript){browser.tabs.executeScript(tab.id,{code:wrapped},()=>{const err=browser.runtime.lastError;if(err)alert('Execution error: '+err.message);});}
    else if(browser.scripting&&browser.scripting.executeScript){await browser.scripting.executeScript({target:{tabId:tab.id},func:c=>{try{(0,eval)(c);}catch(e){console.error(e);}},args:[wrapped]});}
    else{browser.tabs.sendMessage(tab.id,{action:'executeGeneratedCode',code:raw},resp=>{if(!resp)alert('No response from page. Try reload.');else if(!resp.ok)alert('Execution error: '+resp.error);});}

    // Save autorun for this exact origin+path
    const pattern=(()=>{try{const u=new URL(tab.url);return u.origin+u.pathname;}catch{return '';}})();
    if(pattern){const store=await new Promise(r=>browser.storage.local.get('autorunScripts',v=>r(v.autorunScripts||{})));store[pattern]=raw;await new Promise(r=>browser.storage.local.set({autorunScripts:store},r));const st=document.getElementById('autorunStatus');if(st)st.textContent='Auto-run: ON for this page';const btn=document.getElementById('clearAutorun');if(btn)btn.disabled=false;}
  }catch(e){alert('Execution error: '+(e&&e.message?e.message:e));}
});
